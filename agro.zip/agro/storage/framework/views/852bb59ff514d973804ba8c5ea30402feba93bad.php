<footer class="footer-bottom">
  <p class="text-center" style="color: #fff;">&copy; 2021 All rights reserved | Anwar Yousuf Agro</p>
</footer>
