<?php $__env->startSection('content'); ?>
  <div class="main-panel">
    <div class="content-wrapper">

      <div class="card">
        <div class="card-header">
          Add Product
        </div>
        <div class="card-body">
          <form id="myform" action="<?php echo e(route('admin.product.store')); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            
            <?php echo $__env->make('backend.partials.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <div class="form-group">
              <label for="exampleInputEmail1">Title</label>
              <input type="text" class="form-control" name="title" id="vtitle" aria-describedby="emailHelp" placeholder="Enter title">
            </div> 


           




            <div class="form-group">
              <label for="exampleInputPassword1">Description</label>
              <textarea id="descrip"   name="description" rows="8" cols="80" class="form-control"></textarea>

            </div>
            <div class="form-group">
              <label for="exampleInputEmail1">Price</label>
              <input type="number" class="form-control" name="price" id="vprice">
            </div>
            <div class="form-group">
              <label for="exampleInputEmail1">Quantity</label>
              <input type="number" class="form-control" name="quantity" id="vquantity">
            </div>
            <div class="form-group">
              <label for="exampleInputEmail1">Select Category</label>
              <select id="sid"  class="form-control" name="category_id">
                <option  id="sid" value="">Please select a category for the product</option>
                <?php $__currentLoopData = App\Models\Category::orderBy('name', 'asc')->where('parent_id', NULL)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option id="sid"   value="<?php echo e($parent->id); ?>"><?php echo e($parent->name); ?></option>

                  <?php $__currentLoopData = App\Models\Category::orderBy('name', 'asc')->where('parent_id', $parent->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option id="sid"    value="<?php echo e($child->id); ?>"> ------> <?php echo e($child->name); ?></option>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
            <div class="form-group">
              <label for="exampleInputEmail1">Select Brand</label>
              <select class="form-control" name="brand_id">
                <option value="">Please select a brand for the product</option>
                <?php $__currentLoopData = App\Models\Brand::orderBy('name', 'asc')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($brand->id); ?>"><?php echo e($brand->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
            <div class="form-group">
              <label for="product_image">Product Image</label>

              <div class="row">
                <div class="col-md-4">
                  <input type="file" class="form-control" name="product_image[]" id="product_image" >
                </div>
                <div class="col-md-4">
                  <input type="file" class="form-control" name="product_image[]" id="product_image" >
                </div>
                <div class="col-md-4">
                  <input type="file" class="form-control" name="product_image[]" id="product_image" >
                </div>
                <div class="col-md-4">
                  <input type="file" class="form-control" name="product_image[]" id="product_image" >
                </div>
                <div class="col-md-4">
                  <input type="file" class="form-control" name="product_image[]" id="product_image" >
                </div>
              </div>
            </div>

            <button  id="vproduct" type="submit" class="btn btn-primary">Add Product</button>
          </form>
        </div>
      </div>

    </div>
  </div>





  <div>

      <script src="//cdnjs.cloudflare.com/ajax/libs/annyang/2.6.0/annyang.min.js"></script>
      <script>
      if (annyang) {
        // Let's define our first command. First the text we expect, and then the function it should call
        var commands = {
        
          'title *tag': function(variable){

               let vtitle = document.getElementById("vtitle");
               vtitle.value = variable;

          },

          'Description *tag': function(variable){

               let descrip = document.getElementById("descrip");
               descrip.value =variable;

          },
            
          'price *tag': function(variable){

               let vprice = document.getElementById("vprice");
               vprice.value =variable;

          },

             'quantity *tag': function(variable){

               let vquantity = document.getElementById("vquantity");
               vquantity.value =variable;

          },
         
          'Select Category': function(){

               let sid = document.getElementById("sid");
              

          },

          'Add Product   ': function(){

            let myform = document.getElementById("myform");

                 let card = document.queryselector(".card");
                 let heading = document.queryselector(".card-header");
                 myform.remove();


                 let vproduct = document.getElementById("vproduct");
              

          }


        };

        // Add our commands to annyang
        annyang.addCommands(commands);

        // Start listening. You can call this here, or attach this call to an event, button, etc.
        annyang.start();
      }
      </script>



  </div>
  <!-- main-panel ends -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>