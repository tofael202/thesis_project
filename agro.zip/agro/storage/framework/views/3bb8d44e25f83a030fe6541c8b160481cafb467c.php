<footer class="footer-bottom">
  <p class="text-center">&copy; 2018 All rights reserved | Ecommerce Site</p>
</footer>
