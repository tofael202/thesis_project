<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>
    <?php echo $__env->yieldContent('title', 'Anwar Agro'); ?>
  </title>
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <?php echo $__env->make('frontend.partials.styles', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>
<body>

  <div class="wrapper">

    <?php echo $__env->make('frontend.partials.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('frontend.partials.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->yieldContent('content'); ?>
    <?php echo $__env->make('frontend.partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  </div>


  <?php echo $__env->make('frontend.partials.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->yieldContent('scripts'); ?>
  </body>
</html>
