
  <!-- <nav class="navbar sticky-top navbar-expand-lg" style="background-color: #FFF">
  <div class="container">


    <a class="navbar-brand" href="{{ route('index') }}">
      <img src="{{ asset('images/ayagro.png') }}" alt="">
    </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  
  

  

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
       <ul class="navbar-nav mr-auto">
        <li class="nav-item">
          <form class="form-inline my-2 my-lg-0" action="{!! route('search') !!}" method="get">
            {{-- <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
            <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button> --}}
            <div class="input-group mb-3">


              <input type="text" class="form-control" id="speaktheProduct" name="search" placeholder="Search Products" aria-label="Recipient's username" aria-describedby="basic-addon2"  onclick="record()"    >
            
            
              <div class="input-group-append">
                <button class="btn btn-outline-secondary search-icon-button" type="button"><i class="fa fa-search"></i></button>
              </div>
            </div>
          </form>
        </li>
        <li class="nav-item {{ Route::is('index') ? 'active' : '' }}">
          <a class="nav-link" href="{{ route('index') }}">Home <span class="sr-only">(current)</span></a>
        </li>
        <li class="nav-item  {{ Route::is('products') ? 'active' : '' }}">
          <a class="nav-link" href="{{ route('products') }}">Products</a>
        </li>
        <li class="nav-item  {{ Route::is('contact') ? 'active' : '' }}">
          <a class="nav-link" href="{{ route('contact') }}">Contact</a>
        </li>
        

      </ul> 
    

      <ul class="navbar-nav ml-auto">

      
        <li class="nav-item {{ Route::is('index') ? 'active' : '' }}">
          <a class="nav-link" href="{{ route('index') }}">Home <span class="sr-only">(current)</span></a>
        </li>
        <li class="nav-item  {{ Route::is('products') ? 'active' : '' }}">
          <a class="nav-link" href="{{ route('products') }}">Products</a>
        </li>
        <li class="nav-item  {{ Route::is('contact') ? 'active' : '' }}">
          <a class="nav-link" href="{{ route('contact') }}">Contact</a>
        </li>
        <li>
          <a class="nav-link btn-cart-nav" href="{{ route('carts') }}">

            <button class="btn btn-danger">
              <span class="mt-1">Cart</span>
              <span class="badge" id="totalItems">
                {{ App\Models\Cart::totalItems() }}
              </span>
            </button>

          </a>
        </li>
        <li class="nav-item">
          <form class="form-inline my-2 my-lg-0" action="{!! route('search') !!}" method="get">
            {{-- <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
            <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button> --}}
            <div class="input-group mb-3">


              <input type="text" class="form-control" id="speaktheProduct" name="search" placeholder="Search Products" aria-label="Recipient's username" aria-describedby="basic-addon2"  onclick="record()"    >
            
            
              <div class="input-group-append">
                <button class="btn btn-outline-secondary search-icon-button" type="button"><i class="fa fa-search"></i></button>
              </div>
            </div>
          </form>
        </li>
        @guest
           <li><a class="nav-link" href="{{ route('login') }}">Login</a></li> 
           <li><a class="nav-link" href="{{ route('register') }}">Register</a></li> 
        @else
          <li class="nav-item dropdown">
            <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <img src="{{ App\Helpers\ImageHelper::getUserImage(Auth::user()->id) }}" class="img rounded-circle" style="width:40px">
              {{ Auth::user()->first_name }} {{ Auth::user()->last_name }}
              <span class="caret"></span>
            </a>

            <div class="dropdown-menu" aria-labelledby="navbarDropdown">

              <a class="dropdown-item" href="{{ route('user.dashboard') }}">
                My dashboard
              </a>

              <a class="dropdown-item" href="{{ route('logout') }}"
              onclick="event.preventDefault();
              document.getElementById('logout-form').submit();">
              Logout
            </a>

            <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
              @csrf
            </form>
          </div>
        </li>
      @endguest
    </ul>

  </div>
</div>

<div>
   <script>
        function record() {
            var recognition = new webkitSpeechRecognition();
            recognition.lang = "en-GB";

            recognition.onresult = function (event) {
                // console.log(event);
                document.getElementById('speaktheProduct').value = event.results[0][0].transcript;
            }
            recognition.start();

        }
    </script>


</div>


</nav>
      -->
<!-- End Navbar Part -->
      




<nav class="navbar navbar-expand-lg navbar-light font-all pb-0 pt-0 ">
<div class="container">


<a class="navbar-brand" href="{{ route('index') }}">
  <img src="{{ asset('images/aylogo1.png') }}" style="height: 100px;width:160px;"alt="">
</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav ml-auto mt-4">
    <li class="nav-item mr-4">
          <form class="form-inline my-2 my-lg-0" action="{!! route('search') !!}" method="get">
            {{-- <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
            <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button> --}}
            <div class="input-group mb-3">


              <input type="text" class="form-control" id="speaktheProduct" name="search" placeholder="Search Products" aria-label="Recipient's username" aria-describedby="basic-addon2"  onclick="record()"    >
            
            
              <div class="input-group-append">
                <button class="btn btn-outline-secondary search-icon-button" type="button"><i class="fa fa-search"></i></button>
              </div>
            </div>
          </form>
        </li> 
    <li class="nav-item {{ Route::is('index') ? 'active' : '' }}">
          <a class="nav-link font-weight-bold font-all" href="{{ route('index') }}">Home <span class="sr-only">(current)</span></a>
        </li>
        <li class="nav-item  {{ Route::is('products') ? 'active' : '' }}">
          <a class="nav-link font-weight-bold font-all" href="{{ route('products') }}">Products</a>
        </li>
        <li class="nav-item  {{ Route::is('contact') ? 'active' : '' }}">
          <a class="nav-link font-weight-bold font-all" href="{{ route('contact') }}">Contact</a>
        </li>
        <li>
          <a class="nav-link btn-cart-nav  " href="{{ route('carts') }}">

            <button class="btn btn-success pt-0 pb-0">
              <span class="mt-1">Cart</span>
              <span class="badge badge-danger" id="totalItems">
                {{ App\Models\Cart::totalItems() }}
              </span>
            </button>

          </a>
        </li>
        
        @guest
           <!--<li><a class="nav-link" href="{{ route('login') }}">Login</a></li> 
           <li><a class="nav-link" href="{{ route('register') }}">Register</a></li> -->
        @else
          <li class="nav-item dropdown">
            <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <img src="{{ App\Helpers\ImageHelper::getUserImage(Auth::user()->id) }}" class="img rounded-circle" style="width:40px">
              {{ Auth::user()->first_name }} {{ Auth::user()->last_name }}
              <span class="caret"></span>
            </a>

            <div class="dropdown-menu" aria-labelledby="navbarDropdown">

              <a class="dropdown-item" href="{{ route('user.dashboard') }}">
                My dashboard
              </a>

              <a class="dropdown-item" href="{{ route('logout') }}"
              onclick="event.preventDefault();
              document.getElementById('logout-form').submit();">
              Logout
            </a>

            <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
              @csrf
            </form>
          </div>
        </li>
      @endguest
    </ul>

  </div>
</div>

<div>
   <script>
        function record() {
            var recognition = new webkitSpeechRecognition();
            recognition.lang = "en-GB";

            recognition.onresult = function (event) {
                // console.log(event);
                document.getElementById('speaktheProduct').value = event.results[0][0].transcript;
            }
            recognition.start();

        }
    </script>


</div>

</nav>