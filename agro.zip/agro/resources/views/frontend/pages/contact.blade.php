@extends('frontend.layouts.master')

@section('content')
  <div class='container margin-top-20'>
    <h2>Contact Us</h2>
    <hr>

    <div class="row">
    	<div class="col-md-3">
    		<h3>
    			Anwar Agro
    		</h3>
    		<p>
    			<address>
    				Dhaka-1207,
    				<br>
    				Bangladesh
    			</address>
    		</p>
    	</div>
    	<div class="col-md-9">
    		<h5>About Our Business</h5>
    		<p>
    			Lorem ipsum dolor sit amet, consectetur adipisicing elit. Repudiandae expedita odio dignissimos doloremque dicta atque earum, possimus doloribus labore veritatis nisi enim repellendus tempore saepe fugiat, soluta distinctio iure aliquid.
    		</p>
    		<p>
    			Lorem ipsum dolor sit amet, consectetur adipisicing elit. Repudiandae expedita odio dignissimos doloremque dicta atque earum, possimus doloribus labore veritatis nisi enim repellendus tempore saepe fugiat, soluta distinctio iure aliquid.
    		</p>
    		<p>
    			Lorem ipsum dolor sit amet, consectetur adipisicing elit. Repudiandae expedita odio dignissimos doloremque dicta atque earum, possimus doloribus labore veritatis nisi enim repellendus tempore saepe fugiat, soluta distinctio iure aliquid.
    		</p>
    		<p>
    			Lorem ipsum dolor sit amet, consectetur adipisicing elit. Repudiandae expedita odio dignissimos doloremque dicta atque earum, possimus doloribus labore veritatis nisi enim repellendus tempore saepe fugiat, soluta distinctio iure aliquid.
    		</p><p>
    			Lorem ipsum dolor sit amet, consectetur adipisicing elit. Repudiandae expedita odio dignissimos doloremque dicta atque earum, possimus doloribus labore veritatis nisi enim repellendus tempore saepe fugiat, soluta distinctio iure aliquid.
    		</p><p>
    			Lorem ipsum dolor sit amet, consectetur adipisicing elit. Repudiandae expedita odio dignissimos doloremque dicta atque earum, possimus doloribus labore veritatis nisi enim repellendus tempore saepe fugiat, soluta distinctio iure aliquid.
    		</p><p>
    			Lorem ipsum dolor sit amet, consectetur adipisicing elit. Repudiandae expedita odio dignissimos doloremque dicta atque earum, possimus doloribus labore veritatis nisi enim repellendus tempore saepe fugiat, soluta distinctio iure aliquid.
    		</p>
    	</div>
    </div>
    
  </div>
@endsection
